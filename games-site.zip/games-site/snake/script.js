(() => {
  const canvas = document.getElementById('board');
  const ctx = canvas.getContext('2d');
  const scoreEl = document.getElementById('score');
  const bestEl = document.getElementById('best');
  const overlay = document.getElementById('overlay');
  const message = document.getElementById('message');

  const GRID = 20;
  const CELL = canvas.width / GRID;
  const LCD = '#c5d1a0';
  const INK = '#2f3a1e';

  let snake, dir, nextDir, food, score, best = 0, timer;
  let state = 'ready'; // ready | running | paused | over

  try { best = Number(localStorage.getItem('snake-best')) || 0; } catch (e) {}
  bestEl.textContent = best;

  function reset() {
    snake = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
    dir = nextDir = { x: 1, y: 0 };
    score = 0;
    scoreEl.textContent = score;
    placeFood();
    draw();
  }

  function placeFood() {
    let spot;
    do {
      spot = { x: Math.floor(Math.random() * GRID), y: Math.floor(Math.random() * GRID) };
    } while (snake.some(s => s.x === spot.x && s.y === spot.y));
    food = spot;
  }

  function showOverlay(text) {
    message.textContent = text;
    overlay.classList.remove('hidden');
  }

  function start() {
    if (state === 'over' || state === 'ready') reset();
    state = 'running';
    overlay.classList.add('hidden');
    schedule();
  }

  function pause() {
    state = 'paused';
    clearTimeout(timer);
    showOverlay('Paused. Press Space or tap to continue');
  }

  function schedule() {
    clearTimeout(timer);
    const delay = Math.max(60, 140 - score * 3);
    timer = setTimeout(step, delay);
  }

  function step() {
    if (state !== 'running') return;
    dir = nextDir;
    const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
    const eating = head.x === food.x && head.y === food.y;
    const body = eating ? snake : snake.slice(0, -1);

    const hitWall = head.x < 0 || head.y < 0 || head.x >= GRID || head.y >= GRID;
    if (hitWall || body.some(s => s.x === head.x && s.y === head.y)) {
      return gameOver('Game over. Score ' + score + '. Press Space or tap to retry');
    }

    snake.unshift(head);
    if (eating) {
      score++;
      scoreEl.textContent = score;
      if (snake.length === GRID * GRID) {
        draw();
        return gameOver('You filled the board! Press Space or tap to play again');
      }
      placeFood();
    } else {
      snake.pop();
    }
    draw();
    schedule();
  }

  function gameOver(text) {
    state = 'over';
    clearTimeout(timer);
    if (score > best) {
      best = score;
      bestEl.textContent = best;
      try { localStorage.setItem('snake-best', best); } catch (e) {}
    }
    showOverlay(text);
  }

  function draw() {
    ctx.fillStyle = LCD;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // food
    ctx.fillStyle = INK;
    const fx = food.x * CELL, fy = food.y * CELL, m = CELL / 2;
    ctx.beginPath();
    ctx.moveTo(fx + m, fy + 3);
    ctx.lineTo(fx + CELL - 3, fy + m);
    ctx.lineTo(fx + m, fy + CELL - 3);
    ctx.lineTo(fx + 3, fy + m);
    ctx.closePath();
    ctx.fill();

    // snake: head fills its cell, body is slightly inset
    snake.forEach((s, i) => {
      const inset = i === 0 ? 1 : 2;
      ctx.fillRect(s.x * CELL + inset, s.y * CELL + inset, CELL - inset * 2, CELL - inset * 2);
    });
  }

  function turn(dx, dy) {
    // compare to the direction last moved so quick double taps can't reverse into the body
    if (dx === -dir.x && dy === -dir.y) return;
    nextDir = { x: dx, y: dy };
  }

  function toggle() {
    if (state === 'running') pause();
    else start();
  }

  const keys = {
    ArrowUp: [0, -1], w: [0, -1], W: [0, -1],
    ArrowDown: [0, 1], s: [0, 1], S: [0, 1],
    ArrowLeft: [-1, 0], a: [-1, 0], A: [-1, 0],
    ArrowRight: [1, 0], d: [1, 0], D: [1, 0],
  };

  document.addEventListener('keydown', e => {
    if (e.key === ' ') { e.preventDefault(); toggle(); return; }
    const k = keys[e.key];
    if (k) {
      e.preventDefault();
      turn(k[0], k[1]);
      if (state === 'ready' || state === 'over') start();
    }
  });

  overlay.addEventListener('click', toggle);

  // swipe controls
  let touchStart = null;
  canvas.addEventListener('touchstart', e => {
    const t = e.changedTouches[0];
    touchStart = { x: t.clientX, y: t.clientY };
  }, { passive: true });

  canvas.addEventListener('touchend', e => {
    if (!touchStart) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - touchStart.x;
    const dy = t.clientY - touchStart.y;
    touchStart = null;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) return;
    if (Math.abs(dx) > Math.abs(dy)) turn(dx > 0 ? 1 : -1, 0);
    else turn(0, dy > 0 ? 1 : -1);
  });

  reset();
})();
